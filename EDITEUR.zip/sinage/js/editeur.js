var tpl_calque = '<div class="ui-widget-content" style="z-index:30; width:100px;height:100px; top:10px;left:10px;position:absolute"><span class="todrag"><i class="fa fa-arrows" aria-hidden="true"></i></span><span class="fake_after"></span></div>'
var tpl_image = '<div class="ui-widget-content" style="z-index:30; width:100px;height:100px; top:10px;left:10px;position:absolute"><span class="todrag"><i class="fa fa-arrows" aria-hidden="true"></i></span>image<span class="fake_after"></span></div>'
var tpl_p = '<div class="ui-widget-content" style="z-index:30; width:100px;height:100px; top:10px;left:10px;position:absolute; padding:10px;" ><span class="todrag"><i class="fa fa-arrows" aria-hidden="true"></i></span><div class="inner_text" contenteditable="true">Texte exemple</div><span class="fake_after"></span></div>'
var tpl_marquee = '<div class="ui-widget-content" style="z-index:30; width:100px;height:100px; top:10px;left:10px;position:absolute; padding:10px;" ><span class="todrag"><i class="fa fa-arrows" aria-hidden="true"></i></span><marquee><div class="inner_text" contenteditable="true">Texte exemple</div></marquee><span class="fake_after"></span></div>'
//var tpl_p = '<div contenteditable="true" autofocus="true"></div>' 

//var contextmenu = '<ul class="contextmenu"><li class="contextmenu-title"><a href="#">Title</a></li><li id="cut"><a href="#"><i class="fa fa-scissors"></i>Cut</a></li><li id="copy"><a href="#"><i class="fa fa-files-o"></i>Copy</a></li><li id="paste" class="disabled"><a href="#"><i class="fa fa-clipboard"></i>Paste</a></li><li class="contextmenu-divider"><a href="#"></a></li><li id="delete"><a href="#"><i class="fa fa-times"></i>Delete</a></li></ul>'

$(document).ready(function(){
    // ajout de cadre
    $('.calque').on('click', function(){
        $('.ui-widget-content').removeClass('active')


        if($(this).attr('data-tpl') == 'tpl_calque'){
            $(tpl_calque).appendTo('#machine').draggable({ handle: ".todrag" }).resizable().addClass('active');
        }else if($(this).attr('data-tpl') == 'tpl_p'){
            $(tpl_p).appendTo('#machine').draggable({ handle: ".todrag" }).resizable().addClass('active');
        }else if($(this).attr('data-tpl') == 'tpl_image'){
            $(tpl_image).appendTo('#machine').draggable({ handle: ".todrag" }).resizable().addClass('active');
        }else if($(this).attr('data-tpl') == 'tpl_marquee'){
            $(tpl_marquee).appendTo('#machine').draggable({ handle: ".todrag" }).resizable().addClass('active');
        }
    })

    //selection de cadre

    $('#machine').on('click', '.ui-widget-content', function(){
        $('.ui-widget-content').removeClass('active')
        $(this).addClass('active')
    })

    //ajout type de contenu

    $('#machine').on('click', '.text', function(){
        //$('.ui-widget-content').removeClass('active')
        $(this).parent('.ui-widget-content').append(tpl_p)
        $(this).remove()

    })

    // ajout d'image

    $("#img_url_temp").observe_field(1, function( ) {
        if($(this).val() != ''){
            var current_img = '<div class="ui-widget-content" style="min-width:50px;min-height:50px; top:10px;left:10px;position:absolute"><span class="todrag"><i class="fa fa-arrows" aria-hidden="true"></i></span><img src="images/'+$(this).val()+'" alt="" width="100%" class="__inner_child"><span class="fake_after"></span></div>'
            $(current_img).appendTo('#machine').draggable({ handle: ".todrag" }).resizable().addClass('active');
        }
        $('#img_url_temp').attr('value', '')
    });


    // ajout de video

    $("#video_url_temp").observe_field(1, function( ) {
        if($(this).val() != ''){
            current_video = '<div class="ui-widget-content" style="min-width:300px;min-height:150px; top:10px;left:10px;position:relative; display:inline-block">'
            current_video += '<span class="todrag">'
            current_video += '<i class="fa fa-arrows" aria-hidden="true"></i>'
            current_video += '</span>'

            current_video += '<video controls autoplay class=" widget_video inner_child" width="100%">'
                current_video += '<source src="'+$(this).val()+'" type="video/mp4">'
                current_video += 'Le navigateur ne prend pas en charge les vidéos.'
            current_video += '</video>'

            current_video += '<span class="fake_after"></span>'
            current_video += '</div>'

            $(current_video).appendTo('#machine').draggable({ handle: ".todrag" }).resizable().addClass('active');
        }
        $(this).val('')
    });

    


    $( "#machine" ).on( "resize", ".ui-widget-content", function( event, ui ) {
        $(this).find('.inner_child').width($(this).width()).height($(this).height())
    } );


    // fancybox
    $(".fancybox").fancybox({'width': '600','height': '400','type': 'iframe','autoScale': false});

    //



  
})

function deleteCalque(){
    $('body').find('.active').remove()
}

function upCalque(){
    current = $('body').find('.active')
    z_index = current.css( "z-index" )
    current.css('z-index', Number(z_index) + 1)
}

function downCalque(){
    current = $('body').find('.active')
    z_index = current.css( "z-index" )
    current.css('z-index', Number(z_index) - 1)
}

function lastCalque(){
    current = $('body').find('.active')
    z_index = current.css( "z-index" )
    current.css('z-index', 1)
}

function firstCalque(){
    current = $('body').find('.active')
    z_index = current.css( "z-index" )
    current.css('z-index', 1000)
}

function commande(nom, argument) {
  if (typeof argument === 'undefined') {
    argument = '';
  }
  // Exécuter la commande
  document.execCommand(nom, false, argument);
}


window.onbeforeunload = function (e) {
  var e = e || window.event;

  // For IE and Firefox
  if (e) {
    e.returnValue = 'Any string';
  }

  // For Safari
  return 'Any string';
};


function saveSelection() {
    if (window.getSelection) {
        sel = window.getSelection();
        if (sel.getRangeAt && sel.rangeCount) {
            var ranges = [];
            for (var i = 0, len = sel.rangeCount; i < len; ++i) {
                ranges.push(sel.getRangeAt(i));
            }
            return ranges;
        }
    } else if (document.selection && document.selection.createRange) {
        return document.selection.createRange();
    }
    return null;
}

function restoreSelection(savedSel) {
    if (savedSel) {
        if (window.getSelection) {
            sel = window.getSelection();
            sel.removeAllRanges();
            for (var i = 0, len = savedSel.length; i < len; ++i) {
                sel.addRange(savedSel[i]);
            }
        } else if (document.selection && savedSel.select) {
            savedSel.select();
        }
    }
}

function createLink() {
    // There's actually no need to save and restore the selection here. This is just an example.
    var savedSel = saveSelection();
    var url = document.getElementById("url").value;
    alert(url)
    restoreSelection(savedSel);
    document.execCommand("CreateLink", false, url);
}
